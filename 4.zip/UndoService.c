#include "UndoService.h"

#include <stdio.h>
#include <stdlib.h>

UndoService* UndoService_create() {
    UndoService* undoService = (UndoService*) malloc(sizeof(UndoService));
    undoService->history = Container_create(Container_destroy);
    return undoService;
}

void UndoService_destroy(UndoService* undoService) {
    for (int i = 0; i < Container_size(undoService->history); ++i) {
        Container* currentContainer = Container_getElementAtIndex(undoService->history, i);
        Container_destroyElements(currentContainer);
        Container_destroy(currentContainer);
    }
    Container_destroy(undoService->history);
    free(undoService);
}

void UndoService_addToHistory(UndoService* undoService, Container* container) {
    Container_pushElementToEnd(undoService->history, container);
}

Container* UndoService_popFromHistory(UndoService* undoService) {
    if (Container_size(undoService->history) == 0) {
        return NULL;
    }
    Container* previousState = Container_popElementFromEnd(undoService->history);
    return previousState;
}