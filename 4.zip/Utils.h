#pragma once

#include "Container.h"

Container* Utils_getDeepCopyOfFileContainer(Container* container);